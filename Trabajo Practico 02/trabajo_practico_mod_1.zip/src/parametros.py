
#Parametro para configurar los archivos de entrada y salida
ARCH_ENT = 'establecimientos2.txt'
ARCH_FILTRO = 'establecimientos_filtros.txt'
ARCH_LOG = 'log.txt'
ARCH_ESTABLECIMIENTOS = 'establecimientos_filtrados.txt'