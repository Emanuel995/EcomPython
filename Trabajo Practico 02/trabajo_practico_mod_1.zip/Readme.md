# Acerca del Programa
programa que leer un archivo.txt y lo filtra con otro archivo.txt que contiene cueanexos.
Valida cada linea de acuerdo al archivo ``` validar_linea.py ``` 

## Configuracion
se debe parametrizar el archivo ```parametro.py``` con los nombres de los archivos de entrada y salida
